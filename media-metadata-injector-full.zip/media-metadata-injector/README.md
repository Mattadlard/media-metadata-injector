# Media Metadata Injector
Generic README content. See repo for full details.